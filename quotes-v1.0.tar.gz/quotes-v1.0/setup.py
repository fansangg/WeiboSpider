# -*- coding: utf-8 -*-
# @Time    : 2019/11/15 12:06 上午
# @Author  : fansan
# @Site    : 
# @File    : setup.py
from distutils.core import setup

setup(
    name='quotes',#需要打包的名字
    version='v1.0',#版本
    py_modules=['foo.QuotesSpider'],
    requires=('requests', 'lxml', 'openpyxl', 'beautifulsoup4')
)