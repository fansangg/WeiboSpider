# -*- coding: utf-8 -*-
# @Time    : 2019-11-14 00:21
# @Author  : fansan
# @Site    :
# @File    : QuotesSpider.py

import requests
from bs4 import BeautifulSoup
import lxml
from openpyxl import Workbook

class QuotesSpider:

    def __init__(self):
        self.base_url = "http://quotes.money.163.com/fund/jzzs_"
        print("请输入要查询的基金代码")
        print('\n用逗号隔开 逗号要英文的 "," 按回车结束')
        inputCode = input("\n请输入:")
        self.queryList = []
        self.wb = Workbook()
        self.ws = self.wb.active
        self.isDateCreated = False
        self.row = ['B','C','D','E','F','G','H','I','J','K','L']
        self.lastColumn = 0
        self.ws.title = 'quotes'
        self.ws.column_dimensions['A'].width = 10.0
        for i in inputCode.split(","):
            self.queryList.append(i)
        self.rowNum = 0
        self.startDate = input("\n请输入要查询的开始日期(like this '2010-01-01'):")
        self.endDate = input("\n请输入要查询的结束日期(like this '2010-01-01'):")
        self.header = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1 Safari/605.1.15'}
        print("\n\n输入的代码是:" + inputCode)

    def doStart(self):
        print('**************crawling...**************')
        for num,code in enumerate(self.queryList):
            self.rowNum = num
            queryUrl = self.base_url + code + ".html"
            self.request(queryUrl,False)
        print('done!')
        file_name = input('请输入保存名称')
        self.wb.save('%s.xlsx' % file_name)
        input("文件以保存到目录下 '%s.xlsx' 按回车键退出! 记得我的生煎包!" % file_name)
        input('还有油豆腐粉丝汤!!')
        # for i in self.queryList:
        #     queryUrl = self.base_url + i + ".html"
        #     rep = requests.get(queryUrl,params={'start':self.startDate,'end':self.endDate,'sort':'TDATE','order':'asc'},headers=self.header,timeout=5)
        #     if rep.status_code == requests.codes.ok:
        #         self.parseHtml(rep.content)

    def request(self,url,isNext):
        if isNext:
            rep = requests.get(url,headers=self.header, timeout=5)
        else:
            rep = requests.get(url,
                           params={'start': self.startDate, 'end': self.endDate, 'sort': 'TDATE', 'order': 'asc'},
                           headers=self.header, timeout=5)
        if rep.status_code == requests.codes.ok:
            self.parseHtml(rep.content)

    def parseHtml(self,html):
        bs = BeautifulSoup(html, 'lxml')
        table = bs.select('tbody > tr')
        fundsTitle = bs.select('.fn_data_title > h2 > small > a')[0].text.split(' ')[0]
        ##基金名称
        if self.lastColumn == 0:
            if self.rowNum == 0:
                self.ws['A1'] = '日期'
            self.ws['%s1' % str(self.row[self.rowNum])] = fundsTitle
        for num,i in enumerate(table):
            td = i.find_all('td')
            if not self.isDateCreated:
                if self.lastColumn != 0:
                    self.ws['A%s' % str(self.lastColumn+num)] = td[0].text
                else:
                    if self.rowNum == 0:
                        self.ws['A%s' % str(num + 2)] = td[0].text
                if num == len(table)-1:
                    self.isDateCreated = True
            #value
            if self.lastColumn!= 0:
                self.ws['%s%s' % (str(self.row[self.rowNum]), str(self.lastColumn+num))] = td[1].text
            else:
                self.ws.column_dimensions[str(self.row[self.rowNum])].width = 15.0
                self.ws['%s%s' % (str(self.row[self.rowNum]),str(num+2))] = td[1].text

        try:
            nextUrl = bs.select('.pages_flip')[1]['href']
            nextUrl = 'http://quotes.money.163.com' + nextUrl
            self.isDateCreated = False
            self.lastColumn = len(table) + 1
            self.request(nextUrl,True)
        except:
            self.lastColumn = 0
        # print("日期:%s --- 单位净值:%s" % (td[0].text,td[1].text))
        #nextUrl = bs.select('.pages_flip')[1]['href']
        #if nextUrl.isspace():
        #   nextUrl = 'http://quotes.money.163.com'+nextUrl
            #self.request(nextUrl)
